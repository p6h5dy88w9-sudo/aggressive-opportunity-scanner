# Aggressive Opportunity Scanner

Upload these three files to a GitHub Pages repository, then open the HTTPS GitHub Pages URL on iPhone Safari and choose Share → Add to Home Screen.

Enter a Twelve Data API key in the app. The key is stored locally in the browser and requests go directly to Twelve Data.

The scanner ranks trend, RSI, breakout proximity, volume, liquidity and volatility. It is a screening tool, not an automatic trading system or guaranteed signal.
